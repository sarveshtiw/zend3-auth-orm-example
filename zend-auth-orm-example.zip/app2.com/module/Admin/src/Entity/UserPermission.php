<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UserPermission
 *
 * @ORM\Table(name="user_permission")
 * @ORM\Entity
 */
class UserPermission
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="fk_role_id", type="integer", nullable=false)
     */
    private $fkRoleId;

    /**
     * @var integer
     *
     * @ORM\Column(name="fk_controller_id", type="integer", nullable=false)
     */
    private $fkControllerId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="status", type="boolean", nullable=false)
     */
    private $status;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fkRoleId
     *
     * @param integer $fkRoleId
     *
     * @return UserPermission
     */
    public function setFkRoleId($fkRoleId)
    {
        $this->fkRoleId = $fkRoleId;

        return $this;
    }

    /**
     * Get fkRoleId
     *
     * @return integer
     */
    public function getFkRoleId()
    {
        return $this->fkRoleId;
    }

    /**
     * Set fkControllerId
     *
     * @param integer $fkControllerId
     *
     * @return UserPermission
     */
    public function setFkControllerId($fkControllerId)
    {
        $this->fkControllerId = $fkControllerId;

        return $this;
    }

    /**
     * Get fkControllerId
     *
     * @return integer
     */
    public function getFkControllerId()
    {
        return $this->fkControllerId;
    }

    /**
     * Set status
     *
     * @param boolean $status
     *
     * @return UserPermission
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus()
    {
        return $this->status;
    }
}
