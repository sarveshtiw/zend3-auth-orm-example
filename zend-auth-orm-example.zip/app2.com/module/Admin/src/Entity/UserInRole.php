<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UserInRole
 *
 * @ORM\Table(name="user_in_role", indexes={@ORM\Index(name="id", columns={"id"})})
 * @ORM\Entity
 */
class UserInRole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="fk_role_id", type="integer", nullable=false)
     */
    private $fkRoleId;

    /**
     * @var integer
     *
     * @ORM\Column(name="fk_user_id", type="integer", nullable=false)
     */
    private $fkUserId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="status", type="boolean", nullable=false)
     */
    private $status;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fkRoleId
     *
     * @param integer $fkRoleId
     *
     * @return UserInRole
     */
    public function setFkRoleId($fkRoleId)
    {
        $this->fkRoleId = $fkRoleId;

        return $this;
    }

    /**
     * Get fkRoleId
     *
     * @return integer
     */
    public function getFkRoleId()
    {
        return $this->fkRoleId;
    }

    /**
     * Set fkUserId
     *
     * @param integer $fkUserId
     *
     * @return UserInRole
     */
    public function setFkUserId($fkUserId)
    {
        $this->fkUserId = $fkUserId;

        return $this;
    }

    /**
     * Get fkUserId
     *
     * @return integer
     */
    public function getFkUserId()
    {
        return $this->fkUserId;
    }

    /**
     * Set status
     *
     * @param boolean $status
     *
     * @return UserInRole
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus()
    {
        return $this->status;
    }
}
