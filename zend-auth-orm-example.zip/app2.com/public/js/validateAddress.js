function FillBilling(f)
{
    if (f.sameAddress.checked == true)
    {
        f.raddressline1.value = f.paddressline1.value;
        f.raddressline2.value = f.paddressline2.value;
        f.rcountry.value = f.pcountry.value;
        $('#rcity').html($('#pcity').html());
        f.rcity.value = f.pcity.value;
        $('#rstate').html($('#pstate').html());
        f.rstate.value = f.pstate.value;
        f.rpincode.value = f.ppincode.value;
        if ($("#pactive").is(':checked'))
            $("#ractive").prop("checked", true);
    }
    else
    {
        f.raddressline1.value = '';
        f.raddressline2.value = '';
        f.rcountry.value = '';
        f.rcity.value = '';
        f.rstate.value = '';
        f.rpincode.value = '';
        f.ractive.value = '';
        $("#ractive").prop("checked", false);
    }
}
