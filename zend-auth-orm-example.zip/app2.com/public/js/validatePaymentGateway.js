$(document).ready(function () {
    $(document).on('keydown', '#PaymentGatewayStartCount,#PaymentGatewayStartVolume,#PaymentGatewayEndCount,#PaymentGatewayEndVolume,#pPhone', function (event) {
        // Prevent shift key since its not needed
        if (event.shiftKey == true) {
            event.preventDefault();
        }
        // Allow Only: keyboard 0-9, numpad 0-9, backspace, tab, left arrow, right arrow, delete
        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46) {
            // Allow normal operation
        } else {
            // Prevent the rest
            event.preventDefault();
        }
    });
    
    $('#frm').on('keydown', '#IssuerNewCode', function (e) {
        if (!$(this).data("value"))
            $(this).data("value", this.value);
    });
    $('#frm').on('keyup', '#IssuerNewCode', function (e) {
        if (!/^[_0-9a-z]*$/i.test(this.value))
            this.value = $(this).data("value");
        else
            $(this).data("value", null);
    });

    $('#add-more-parms').click(function () {
        $('.error-msg').html('');
        var ParameterNewId = $('#ParameterNewId').val();
        if (ParameterNewId == '')
        {
            $('#ParameterNewId').next('span').text('Please Select Parameter.');
            return false;
        }
        var ParameterNewName = $("#ParameterNewId option:selected").text();
        
        var ParameterNewValue = $('#ParameterNewValue').val();
        
        if (ParameterNewValue == '')
        {
            $('#ParameterNewValue').next('span').text('Please enter value.');
            return false;
        }
        if(ParameterNewName=='Request Url' || ParameterNewName=='Return Url')
        {
            var data=is_valid_url(ParameterNewValue);
            if(data==false)
            {
                $('#ParameterNewValue').next('span').text('Please enter right url.');
                return false;
            }
        }
        
        
        var countDuplicate=0;
        $.each($("#parameter-table tbody").find("tr"), function () { 
            if($('#ParameterNewId').val()==$(this).find('#ParameterId').val())
            {
                $('#error-Parameter').text('This parameter is already in list.');
                countDuplicate++;
            }
        });
        if(countDuplicate>0)
        {
            var ParameterNewId = $('#ParameterNewId').val('');
            $('#ParameterNewValue').val(''); 
            $(this).html('Add More');
            return false; 
        }
        else
        {
            $("#no-result").remove();

            var newRowContent = '<tr class="odd gradeX"><td><input type="hidden" name="PaymentGatewayConnectionParameterId[]" id="PaymentGatewayConnectionParameterId" value=""><span>' + ParameterNewName + '</span><input type="hidden" name="ParameterId[]" id="ParameterId" value=' + ParameterNewId + '></td><td><span>' + ParameterNewValue + '</span><input type="hidden" name="ParameterValue[]" id="ParameterValue" value=' + ParameterNewValue + '></td><td><a href="javascript:void(0);" style="border: 0px !important;margin-right: 4px;" id="edit-parms">Edit</a><a href="javascript:void(0);" style="border: 0px !important;" id="delete-parms">Delete</a><input type="hidden" name="parms-status[]" id="parms-status" value="1"></td></tr>';

            $("#parameter-table tbody").append(newRowContent);
            var countValue = $('#countParameters').val();
            $('#countParameters').val(parseInt(countValue) + 1);
            var ParameterNewId = $('#ParameterNewId').val('');
            $('#ParameterNewValue').val(''); 
            $(this).html('Add More');
        }
       
    });

    $('#add-more-payments').click(function () {

        $('.error-msg').html('');

        var PaymentMethodNewId = $('#PaymentMethodNewId').val();
        if (PaymentMethodNewId == '')
        {
            $('#PaymentMethodNewId').next('span').text('Please Select Payment Method.');
            return false;
        }
        var PaymentMethodNewName = $("#PaymentMethodNewId option:selected").text();
        

        var PaymentMethodNewIssuer = $('#PaymentMethodNewIssuer').val();
        if (PaymentMethodNewIssuer == '')
        {
            $('#PaymentMethodNewIssuer').next('span').text('Please Select Issuer.');
            return false;
        }
        var PaymentMethodIssuerNewName = $("#PaymentMethodNewIssuer option:selected").text();

        var IssuerNewCode = $('#IssuerNewCode').val();
        if (IssuerNewCode == '')
        {
            $('#IssuerNewCode').next('span').text('Please Enter Issuer Code.');
            return false;
        }
        
         var countPayment=0;
        $.each($("#payment-gateway-table tbody").find('tr'), function () { 
            var existId=$(this).find('#PaymentMethodId').val();
            var newId=$('#PaymentMethodNewId').val();
            var newIssuerId=$('#PaymentMethodNewIssuer').val();
            var existIssuerId=$(this).find('#IssuerId').val();
            
            if((newId==existId) && (newIssuerId==existIssuerId))
            {
                $('#error-PaymentMethod').text('This method is already in list.');
                countPayment++; 
            }
        });
        if(countPayment>0)
        {
            return false; 
        }
        else
        {
            $("#no-result-payment").remove();

            var newRowContent = '<tr class="odd gradeX"><td><input type="hidden" name="PaymentGatewayServiceId[]" id="PaymentGatewayServiceId" value="">' + PaymentMethodNewName + '<input type="hidden" name="PaymentMethodId[]" id="PaymentMethodId" value=' + PaymentMethodNewId + '></td><td>' + PaymentMethodIssuerNewName + '<input type="hidden" name="IssuerId[]" id="IssuerId" value=' + PaymentMethodNewIssuer + '></td><td><span>' + IssuerNewCode + '</span><input type="hidden" name="IssuerCode[]" id="IssuerCode" value=' + IssuerNewCode + '></td><td><a href="javascript:void(0);" style="border: 0px !important;margin-right: 4px;" id="edit-methods">Edit</a><a href="javascript:void(0);" style="border: 0px !important;" id="delete-methods">Delete</a><input type="hidden" name="methods-status[]" id="methods-status" value="1"></td></tr>';


            $("#payment-gateway-table tbody").append(newRowContent);
            var countValue = $('#countPaymentMethod').val();
            $('#countPaymentMethod').val(parseInt(countValue) + 1);
            
            $('#PaymentMethodNewId').val('');
            $('#PaymentMethodNewIssuer').val('');
            $('#IssuerNewCode').val('');
            $(this).html('Add More');
        }
       
    });
    
    
    /* More add more emi */
    
    $('#add-more-emi').click(function () {
        
        $('.error-msg').html('');

        var MID = $('#MID').val();
        if(MID=='') 
        {
            $('#MID').next('span').text('Please enter MID.');
            return false;
        }
        
        var GatewayKey = $('#GatewayKey').val();
        if(GatewayKey=='') 
        {
            $('#GatewayKey').next('span').text('Please enter Gateway Key.');
            return false;
        }
        
        var AccessKey = $('#AccessKey').val();
        if(AccessKey=='') 
        {
            $('#AccessKey').next('span').text('Please enter Access Key.');
            return false;
        }
        
        var RedirectUrl = $('#RedirectUrl').val();
        var data=is_valid_url(RedirectUrl);
        if(RedirectUrl=='') 
        {
            $('#RedirectUrl').next('span').text('Please enter Redirect Url.');
            return false;
        }
        else if(data==false)
        {
            $('#RedirectUrl').next('span').text('Please enter right url.');
            return false;
        }
        
        var ReturnUrl = $('#ReturnUrl').val();
        var data1=is_valid_url(RedirectUrl);
        if(ReturnUrl=='') 
        {
            $('#ReturnUrl').next('span').text('Please enter Return Url.');
            return false;
        }
        else if(data1==false)
        {
            $('#ReturnUrl').next('span').text('Please enter right url.');
            return false;
        }
        
        var TenorDuration = $('#TenorDuration').val();
        if(TenorDuration=='') 
        {
            $('#TenorDuration').next('span').text('Please enter Tenor Duration.');
            return false;
        }
        var InterestRate = $('#InterestRate').val();
        if(InterestRate=='') 
        {
            $('#InterestRate').next('span').text('Please enter Interest Rate.');
            return false;
        }
        
        var StatusEmi=$('#Status-Emi').val();
        var StatusEmiValue='InActive';
        if(StatusEmi==1) 
        {
            StatusEmiValue='Active';
        }
        
        var newRowContent = '<tr class="odd gradeX"><td><input type="hidden" name="PaymentGatewayEmiParameterId[]" id="PaymentGatewayEmiParameterId" value=""><span>' + MID + '</span><input type="hidden" name="MID[]" id="MID" value=' + MID + '></td><td><span>' + GatewayKey + '</span><input type="hidden" name="GatewayKey[]" id="GatewayKey" value=' + GatewayKey + '></td><td><span>' + AccessKey + '</span><input type="hidden" name="AccessKey[]" id="AccessKey" value=' + AccessKey + '></td><td><span>' + RedirectUrl + '</span><input type="hidden" name="RedirectUrl[]" id="RedirectUrl" value=' + RedirectUrl + '></td><td><span>' + ReturnUrl + '</span><input type="hidden" name="ReturnUrl[]" id="ReturnUrl" value=' + ReturnUrl + '></td><td><span>' + TenorDuration + '</span><input type="hidden" name="TenorDuration[]" id="TenorDuration" value=' + TenorDuration + '></td><td><span>' + InterestRate + '</span><input type="hidden" name="InterestRate[]" id="InterestRate" value=' + InterestRate + '></td><td><a href="javascript:void(0);" style="border: 0px !important;margin-right: 4px;" id="edit-parms">Edit</a><a href="javascript:void(0);" style="border: 0px !important;" id="delete-parms">Delete</a><input type="hidden" name="Emi-status[]" id="Emi-status" value="1"></td></tr>';
        
        $("#emi-table tbody").append(newRowContent);
        var countValue = $('#countEmi').val();
        $('#countEmi').val(parseInt(countValue) + 1);

        $('#MID').val('');
        $('#GatewayKey').val('');
        $('#AccessKey').val('');
        $('#RedirectUrl').val('');
        $('#ReturnUrl').val('');
        $('#TenorDuration').val('');
        $('#InterestRate').val('');
        $('#TenorDuration').val('');
        
        $(this).html('Add More');
    });
    
    
    $('.nav').on('click', '#parameters-view,#rates-view,#payment-methods-view,#address-view,#contacts-view,#emi-view', function () {
        
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        if(status!='contacts')
        {
            var ajax_dta = ajaxValidate(status, page_name, frm_data,'next');
        }
        var IsError=$('#IsError').val();
        if(IsError==1)
        {
             return false;
        }
        
        ($(this).attr('id') == 'parameters-view') ? $('#frm_status').val('home') : '';
        ($(this).attr('id') == 'rates-view') ? $('#frm_status').val('parameters') : '';
        ($(this).attr('id') == 'payment-methods-view') ? $('#frm_status').val('rates') : '';
        ($(this).attr('id') == 'emi-view') ? $('#frm_status').val('payment-methods') : '';
        ($(this).attr('id') == 'contacts-view') ? $('#frm_status').val('address') : '';
        ($(this).attr('id') == 'address-view') ? $('#frm_status').val('emi') : '';
        GatewayNext();
    });
    
    $('.nav').on('click', '#parameters-view-tab,#rates-view-tab,#payment-methods-view-tab,#address-view-tab,#contacts-view-tab,#emi-view-tab', function () {
        
        ($(this).attr('id') == 'parameters-view-tab') ? $('#frm_status').val('home') : '';
        ($(this).attr('id') == 'rates-view-tab') ? $('#frm_status').val('parameters') : '';
        ($(this).attr('id') == 'payment-methods-view-tab') ? $('#frm_status').val('rates') : '';
        ($(this).attr('id') == 'emi-view-tab') ? $('#frm_status').val('payment-methods') : '';
        ($(this).attr('id') == 'contacts-view-tab') ? $('#frm_status').val('address') : '';
        ($(this).attr('id') == 'address-view-tab') ? $('#frm_status').val('emi') : '';
        GatewayNext();
    });
    
    $('#home-view').click(function () {
        $('#frm_status').val('home');
        $('#previous').addClass('hidden');
        $('#next').removeClass('hidden');
        $('#save').addClass('hidden');
    });
    
    // Edit parameter here
    $('#parameter-table').on('click','#edit-parms',function(){
        var data=$(this).parent().parent().find('#ParameterValue').attr('type','text');
        $(this).parent().parent().find('#ParameterValue').prev().html('');
        
    });
    
    $('#parameter-table').on('blur','#ParameterValue',function(){
        $(this).parent().parent().find('#ParameterValue').prev().html($(this).val());
        var data=$(this).parent().parent().find('#ParameterValue').attr('type','hidden');
        
    });
    
    // Edit Status of paameter  here
    $('#parameter-table').on('click','#status-parms',function(){
        var data=$(this).next().val();
        if(data==0)
        {
            $(this).next().val('1');
            $(this).html('Active');
        }
        if(data==1)
        {
            $(this).next().val('0');
            $(this).html('InActive');
        }
        
    });
    // Delete parms row here
    $('#parameter-table').on('click','#delete-parms',function(){
        $(this).parent().parent().remove();
    });
    
    // Edit Payment gateway here
    $('#payment-gateway-table').on('click','#edit-methods',function(){
        var data=$(this).parent().parent().find('#IssuerCode').attr('type','text');
        $(this).parent().parent().find('#IssuerCode').prev().html('');
        
    });
    
    $('#payment-gateway-table').on('blur','#IssuerCode',function(){
        $(this).parent().parent().find('#IssuerCode').prev().html($(this).val());
        var data=$(this).parent().parent().find('#IssuerCode').attr('type','hidden');
        
    });
    
    // Edit Status of Payment Method  here
    $('#payment-gateway-table').on('click','#status-methods',function(){
        var data=$(this).next().val();
        if(data==0)
        {
            $(this).next().val('1');
            $(this).html('Active');
        }
        if(data==1)
        {
            $(this).next().val('0');
            $(this).html('InActive');
        }
        
    });
    // Delete payemnt methods row here
    $('#payment-gateway-table').on('click','#delete-methods',function(){
        $(this).parent().parent().remove();
    });
    
    
    $('#emi-table').on('click','#edit-emi',function(){
        var data=$(this).parent().parent().find('#MID').attr('type','text');
        $(this).parent().parent().find('#MID').prev().html('');
        
        var data=$(this).parent().parent().find('#GatewayKey-new').attr('type','text');
        $(this).parent().parent().find('#GatewayKey-new').prev().html('');
        
        var data=$(this).parent().parent().find('#AccessKey').attr('type','text');
        $(this).parent().parent().find('#AccessKey').prev().html('');
        
        var data=$(this).parent().parent().find('#RedirectUrl').attr('type','text');
        $(this).parent().parent().find('#RedirectUrl').prev().html('');
        
        var data=$(this).parent().parent().find('#ReturnUrl').attr('type','text');
        $(this).parent().parent().find('#ReturnUrl').prev().html('');
        
        var data=$(this).parent().parent().find('#TenorDuration').attr('type','text');
        $(this).parent().parent().find('#TenorDuration').prev().html('');
        
        var data=$(this).parent().parent().find('#InterestRate').attr('type','text');
        $(this).parent().parent().find('#InterestRate').prev().html('');
        
        
    });
    
    $('#emi-table').on('blur','#MID,#GatewayKey-new,#AccessKey,#RedirectUrl,#ReturnUrl,#TenorDuration,#InterestRate',function(){
        var Id=$(this).attr('id');
        $(this).parent().parent().find('#'+Id).prev().html($(this).val());
        var data=$(this).parent().parent().find('#'+Id).attr('type','hidden');
    });
    
    $('#emi-table').on('click','#status-emi',function(){
        var data=$(this).next().val();
        if(data==0)
        {
            $(this).next().val('1');
            $(this).html('InActive');
        }
        if(data==1)
        {
            $(this).next().val('0');
            $(this).html('Active');
        }
    });
    
    
    // View Details
    
    $('#previous-view').click(function(){
        GatewayPrevious();
    });
    $('#next-view').click(function(){
        GatewayNext();
    });
    
});
function is_valid_url(url) {
   // return /^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(url);
    return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}
function GatewayNext()
{
    var status = $('#frm_status').val();
    var Id=$('#PaymentGatewayId').val();
    if (status == 'home')
    {
        $('#frm_status').val('parameters');
        $('#home').removeClass('active');
        $('#parameters').addClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#parameters-view').addClass('active');
        $('#parameters-view-tab').addClass('active');
        return false;
    }
    if (status == 'parameters')
    {
        $('#frm_status').val('rates');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').addClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#rates-view').addClass('active');
        $('#rates-view-tab').addClass('active');
        return false;
    }
    if (status == 'rates')
    {
        $('#frm_status').val('payment-methods');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').addClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#payment-methods-view').addClass('active');
        $('#payment-methods-view-tab').addClass('active');
        return false;
    }
    if (status == 'payment-methods')
    {
        $('#frm_status').val('emi');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').addClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#emi-view').addClass('active');
        $('#emi-view-tab').addClass('active');
        return false;
    }
    
    if (status == 'emi')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').addClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
    
    if (status == 'address')
    {
        $('#frm_status').val('contacts');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').addClass('active');
        $('.previous').removeClass('hidden');
        $('.next').addClass('hidden');
        $('#save').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#contacts-view').addClass('active');
        $('#contacts-view-tab').addClass('active');
        return false;
    }
}
function GatewayPrevious()
{
    var status = $('#frm_status').val();
    var Id=$('#PaymentGatewayId').val();
    if (status == 'parameters')
    {
        $('#frm_status').val('home');
        $('#home').addClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').addClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#home-view').addClass('active');
        $('#home-view-tab').addClass('active');
        return false;
    }
    if (status == 'rates')
    {
        $('#frm_status').val('parameters');
        $('#home').removeClass('active');
        $('#parameters').addClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').removeClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#parameters-view').addClass('active');
        $('#parameters-view-tab').addClass('active');
        return false;
    }
    if (status == 'payment-methods')
    {
        $('#frm_status').val('rates');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').addClass('active');
        $('#payment-methods').removeClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').removeClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#rates-view').addClass('active');
        $('#rates-view-tab').addClass('active');
        return false;
    }
    if (status == 'address')
    {
        $('#frm_status').val('payment-methods');
        $('#home').removeClass('active');
        $('#parameters').removeClass('active');
        $('#rates').removeClass('active');
        $('#payment-methods').addClass('active');
        $('#emi').removeClass('active');
        $('#address').removeClass('active');
        $('.next').removeClass('hidden');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#payment-methods-view').addClass('active');
        $('#payment-methods-view-tab').addClass('active');
        return false;
    }
    if (status == 'contacts')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#rates').removeClass('active');
        $('#address').addClass('active');
        $('#emi').removeClass('active');
        $('.next').removeClass('hidden');
        $('#contacts').removeClass('active');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
}


