$(document).ready(function () {
    $('.nav').on('click', '#permission-view', function () {
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        if(status!='contacts')
        {
            var ajax_dta = ajaxValidate(status, page_name, frm_data,'next');
        }
        var IsError=$('#IsError').val();
        if(IsError==1)
        {
             return false;
        }
        ($(this).attr('id') == 'permission-view') ? $('#frm_status').val('home') : '';
        RoleNext();
    });
    $('#home-view').click(function () {
        $('#frm_status').val('home');
        $('#previous').addClass('hidden');
        $('#next').removeClass('hidden');
        $('#save').addClass('hidden');
    });
    // View Details
    
    $('#previous-view').click(function(){
        RolePrevious();
    });
    $('#next-view').click(function(){
        RoleNext();
    });
});

function RoleNext()
{
    var status = $('#frm_status').val();
    if (status == 'home')
    {
        $('#frm_status').val('permission');
        $('#home').removeClass('active');
        $('#permission').addClass('active');
        $('.next').addClass('hidden');
        $('.previous').removeClass('hidden');
        $('#save').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#permission-view').addClass('active');
        $('#permission-view-tab').addClass('active');
        return false;
    }

}
function RolePrevious()
{
    var status = $('#frm_status').val();
    var Id=$('#RoleId').val();
    if (status == 'permission')
    {
        $('#frm_status').val('home');
        $('#home').addClass('active');
        $('#permission').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').addClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#home-view').addClass('active');
        $('#home-view-tab').addClass('active');
        return false;
    }
}
$(document).ready(function () {
    $('#frm').submit(function () {
        if ($('#frm input:checked').length <= 0)
        {
            $('#error-permission').html('Please check atleast one checkbox.');
            return false;
        }
    })
});