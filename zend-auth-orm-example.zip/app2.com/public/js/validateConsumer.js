$(document).ready(function () {
    $(document).on('keydown', '#PaymentGatewayStartCount,#PaymentGatewayStartVolume,#PaymentGatewayEndCount,#PaymentGatewayEndVolume', function (event) {
        // Prevent shift key since its not needed
        if (event.shiftKey == true) {
            event.preventDefault();
        }
        // Allow Only: keyboard 0-9, numpad 0-9, backspace, tab, left arrow, right arrow, delete
        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46) {
            // Allow normal operation
        } else {
            // Prevent the rest
            event.preventDefault();
        }
    });
    
    
    $('#frm').on('keydown', '#ConsumerCode', function (e) {
        if (!$(this).data("value"))
            $(this).data("value", this.value);
    });
    $('#frm').on('keyup', '#ConsumerCode', function (e) {
        if (!/^[-0-9a-z ]*$/i.test(this.value))
            this.value = $(this).data("value");
        else
            $(this).data("value", null);
    });

// aJAX Call
    $('#add-more').click(function () {
        $('.error-msg').html('');
        $('#PaymentGatewayNewId').next('span').text('');
        $('#NewCredentials').next('span').text('');
        var paymentGatewayId = $('#PaymentGatewayNewId').val();
        if (paymentGatewayId == '')
        {
            $('#PaymentGatewayNewId').next('span').text('Please Select Payment Gateway');
            return false;
        }
        var paymentGatewayName = $("#PaymentGatewayNewId option:selected").text();
        var NewCredentials = $('#NewCredentials').val();
        if (NewCredentials == '')
        {
            $('#NewCredentials').next('span').text('Please Select Credentials');
            return false;
        }
        var Preferred = $('#NewPreferred').is(':checked');
        var NewPreferred = '';
        var NewPreferredValue=0;
        if (Preferred == true) {
            NewPreferred = 'Yes';
            NewPreferredValue=1;
        } else {
            NewPreferred = 'No';
            NewPreferredValue=0;
        }
        var Default = $('#NewDefault').is(':checked');
        var NewDefault = '';
        var NewDefaultValue=0;
        if (Default == true) {
            NewDefault = 'Yes';
            NewDefaultValue=1;
        } else {
            NewDefault = 'No';
            NewDefaultValue=0;
        }
        
         var countDuplicate=0;
        $.each($("#payment-gateway-table tbody").find("tr"), function () { 
            if($('#PaymentGatewayNewId').val()==$(this).find('#PaymentGatewayId').val())
            {
                $('#error-PaymentGatewayId').text('This gateway is already in list.');
                countDuplicate++;
            }
        });
        if(countDuplicate>0)
        {
            $('#NewPreferred').prop('checked', false);
            $('#NewDefault').prop('checked', false);
            $(this).html('Add More');
            return false; 
        }
        else
        {
            $("#no-result").remove();

            var newRowContent = '';
            var newRowContent = '<tr class="odd gradeX"><td><input type="hidden" name="ConsumerPaymentGatewayLinkId[]" id="ConsumerPaymentGatewayLinkId" value="">' + paymentGatewayName + '<input type="hidden" name="PaymentGatewayId[]" id="PaymentGatewayId" value=' + paymentGatewayId + '></td><td><span>' + NewCredentials + '</span><input type="hidden" name="Credentials[]" id="Credentials" value=' + NewCredentials + '></td><td><span>' + NewPreferred + '</span><input type="hidden" name="PaymentGatewayPreferred[]" id="PaymentGatewayPreferred" value=' + NewPreferredValue + '></td><td><span>' + NewDefault + '</span><input type="hidden" name="PaymentGatewayDefault[]" id="PaymentGatewayDefault" value=' + NewDefaultValue + '></td><td><a href="javascript:void(0);" id="edit-gateway" style="border: 0px !important;margin-right: 4px;">Edit</a><a href="javascript:void(0);" id="delete-gateway" style="border: 0px !important;">Delete</a><input type="hidden" name="gateway-status[]" id="gateway-status" value="1"></td></tr>';

            $("#payment-gateway-table tbody").append(newRowContent);
            var countValue = $('#countPaymentGateway').val();
            $('#countPaymentGateway').val(parseInt(countValue) + 1);

            var paymentGatewayId = $('#PaymentGatewayNewId').val('');
            var NewCredentials = $('#NewCredentials').val('');
            $('#NewPreferred').prop('checked', false);
            $('#NewDefault').prop('checked', false);
            $(this).html('Add More');
            return true;
        }
        
    });


    $('#add-more-method').click(function () {
        $('.error-msg').html('');
        var PaymentMethodNewId = $('#PaymentMethodNewId').val();
        if (PaymentMethodNewId == '')
        {
            $('#PaymentMethodNewId').next('span').text('Please Select Payment Method');
            return false;
        }
        var PaymentMethodNewName = $("#PaymentMethodNewId option:selected").text();
        var PaymentMethodNewStatus = $('#PaymentMethodNewStatus').val();

        var status = '';
        if (PaymentMethodNewStatus == 1)
        {
            var status = 'Active';
        }
        else
        {
            var status = 'InActive';
        }
        
        
        var countDuplicate=0;
        $.each($("#method-table tbody").find("tr"), function () { 
            if($('#PaymentMethodNewId').val()==$(this).find('#PaymentMethodId').val())
            {
                $('#error-PaymentMethodId').text('This method is already in list.');
                countDuplicate++;
            }
        });
        if(countDuplicate>0)
        {
            $('#NewPreferred').prop('checked', false);
            $('#NewDefault').prop('checked', false);
            $(this).html('Add More');
            return false; 
        }
        else
        {
        
            $("#no-result-method").remove();
            var newRowContent = '';
            var newRowContent = '<tr class="odd gradeX"><td><input type="hidden" name="ConsumerPaymentMethodLinkId[]" id="ConsumerPaymentMethodLinkId" value="">' + PaymentMethodNewName + '<input type="hidden" name="PaymentMethodId[]" id="PaymentMethodId" value=' + PaymentMethodNewId + '></td><td><span>' + status + '</span><input type="hidden" name="PaymentMethodStatus[]" id="PaymentMethodStatus" value=' + PaymentMethodNewStatus + '></td><td><a href="javascript:void(0);" id="method-delete">Delete</td></tr>';

            $("#method-table tbody").append(newRowContent);
            var countValue = $('#CountPaymentMethod').val();
            $('#CountPaymentMethod').val(parseInt(countValue) + 1);

            $('#PaymentMethodNewId').val('');
            $('#PaymentMethodNewStatus').val(0);
            $(this).html('Add More');
        }

    });

    $('.nav').on('click', '#payment-gateway-view,#payment-method-view,#address-view,#contacts-view', function () {
        
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        if(status!='contacts')
        {
            var ajax_dta = ajaxValidate(status, page_name, frm_data,'next');
        }
        var IsError=$('#IsError').val();
        if(IsError==1)
        {
             return false;
        }
        
        ($(this).attr('id') == 'payment-gateway-view') ? $('#frm_status').val('home') : '';
        ($(this).attr('id') == 'payment-method-view') ? $('#frm_status').val('paymentGateway') : '';
        ($(this).attr('id') == 'contacts-view') ? $('#frm_status').val('address') : '';
        ($(this).attr('id') == 'address-view') ? $('#frm_status').val('paymentMethod') : '';
        ConsumerNext();
    });
    $('#home-view').click(function () {
        $('#frm_status').val('home');
        $('#previous').addClass('hidden');
        $('#next').removeClass('hidden');
        $('#save').addClass('hidden');
    });
    
    // Edit payement Gateway here
    $('#payment-gateway-table').on('click','#edit-gateway',function(){
        
        // Edit Credintial\
        var Creval=$(this).parent().parent().find('#Credentials').val();
        
        if($(this).parent().parent().find('#NewCredentials').length==0)
        {
            var html="<select name='NewCredentials[]' id='NewCredentials'><option value='B2B'>B2B</option><option value='B2C'>B2C</option></select>";
            $(this).parent().parent().find('#Credentials').after(html);
        }
        else {
            $(this).parent().parent().find('#NewCredentials').show();
        }
        
        $(this).parent().parent().find('#Credentials').prev().html('');
        
        // Edit PaymentGatewayPreferred
        if($(this).parent().parent().find('#NewPreferred').length==0)
        {
            var html2="<select name='NewPreferred[]' id='NewPreferred'><option value='1'>Yes</option><option value='0'>No</option></select>";
            $(this).parent().parent().find('#PaymentGatewayPreferred').after(html2);
        }
        else {
            $(this).parent().parent().find('#NewPreferred').show();
        }
        $(this).parent().parent().find('#PaymentGatewayPreferred').prev().html('');
        
        // Edit IsDefault
        if($(this).parent().parent().find('#NewDefault').length==0)
        {   
            var html3="<select name='NewDefault[]' id='NewDefault'><option value='1'>Yes</option><option value='0'>No</option></select>";
            $(this).parent().parent().find('#PaymentGatewayDefault').after(html3);
        }
        else {
            $(this).parent().parent().find('#NewDefault').show();
        }
        $(this).parent().parent().find('#PaymentGatewayDefault').prev().html('');
        
    });
    
    $('#payment-gateway-table').on('blur','#NewCredentials',function(){
        
        // Edit Credintial
        var cret=$(this).val();
        $(this).prev().val(cret);
        $(this).prev().prev().html(cret);
        $(this).hide();
    });
     $('#payment-gateway-table').on('blur','#NewPreferred,#NewDefault',function(){
        
        // Edit Credintial
        var cret=$(this).val();
        var val=(cret==0)?'No': 'Yes';
        var Id=$(this).prev().attr('id');
        //$('#'+Id).val(cret);
        $(this).prev().val(cret);
        $(this).prev().prev().html(val);
        $(this).hide();
    });
    
    $('#payment-gateway-table').on('click','#status-gateway',function(){
        var data=$(this).next().val();
        if(data==0)
        {
            $(this).next().val('1');
            $(this).html('Active');
        }
        if(data==1)
        {
            $(this).next().val('0');
            $(this).html('InActive');
        }
        
    });
    
    // Delete payemnt gateway row here
    $('#payment-gateway-table').on('click','#delete-gateway',function(){
        $(this).parent().parent().remove();
    });
    
    $('#method-table').on('click','#method-delete',function(){
        $(this).parent().parent().remove();
    });
    $('#method-table').on('click','#status-method',function(){
        var data=$(this).next().val();
        if(data==0)
        {
            $(this).parent().prev().find('#PaymentMethodStatus').val('1');
            $(this).html('InActive');
            $(this).next().val('1');
            $(this).parent().prev().find('span').html('Active');
        }
        if(data==1)
        {
            $(this).parent().prev().find('#PaymentMethodStatus').val('0');
            $(this).html('Active');
            $(this).next().val('0');
            $(this).parent().prev().find('span').html('InActive');
        }
        
    });
    
    // View Details
    
    $('#previous-view').click(function(){
        ConsumerPrevious();
    });
    $('#next-view').click(function(){
        ConsumerNext();
    });

});
function ConsumerNext()
{
    var status = $('#frm_status').val();
    if (status == 'home')
    {
        $('#frm_status').val('paymentGateway');
        $('#home').removeClass('active');
        $('#payment-gateway').addClass('active');
        $('#payment-method').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#payment-gateway-view').addClass('active');
        $('#payment-gateway-view-tab').addClass('active');
        return false;
    }
    if (status == 'paymentGateway')
    {
        $('#frm_status').val('paymentMethod');
        $('#home').removeClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').addClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#payment-method-view').addClass('active');
        $('#payment-method-view-tab').addClass('active');
        return false;
    }
    if (status == 'paymentMethod')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').removeClass('active');
        $('#address').addClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
    if (status == 'address')
    {
        $('#frm_status').val('contacts');
        $('#home').removeClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').addClass('active');
        $('.previous').removeClass('hidden');
        $('.next').addClass('hidden');
        $('#save').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#contacts-view').addClass('active');
        $('#contacts-view-tab').addClass('active');
        return false;
    }
}
function ConsumerPrevious()
{
    var status = $('#frm_status').val();
    var Id=$('#ConsumerId').val();
    if (status == 'paymentGateway')
    {
        $('#frm_status').val('home');
        $('#home').addClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').addClass('hidden');
        $('#contacts-view-tab').addClass('active');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#home-view').addClass('active');
        return false;
    }
    if (status == 'paymentMethod')
    {
        $('#frm_status').val('paymentGateway');
        $('#home').removeClass('active');
        $('#payment-gateway').addClass('active');
        $('#payment-method').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#payment-gateway-view').addClass('active');
        $('#payment-gateway-view-tab').addClass('active');
        return false;
    }
    if (status == 'address')
    {
        $('#frm_status').val('paymentMethod');
        $('#home').removeClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').addClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#payment-method-view').addClass('active');
        $('#payment-method-view-tab').addClass('active');
        return false;
    }

    if (status == 'contacts')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#payment-gateway').removeClass('active');
        $('#payment-method').removeClass('active');
        $('#address').addClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('#contacts').removeClass('active');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
}

function is_valid_url(url) {
   // return /^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(url);
    return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}


