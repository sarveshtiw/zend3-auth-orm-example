$(document).ready(function () {
    $("#searchFrom").datetimepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selected) {
            $("#searchTo").datetimepicker("option", "minDate", selected);
        }
    });

    $("#searchTo").datetimepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selected) {
            $("#searchFrom").datetimepicker("option", "maxDate", selected)
        }
    });
    $('#pagination a').click(function () {
        var url = $(this).attr('href');
        $(this).attr('href', 'javascript:void(0);')
        $('#frm').attr('action', url);
        $('#frm').trigger('submit');
    });
    $('#export-csv').click(function () {
        $('#action_button').attr('value', 'export-csv');
        $('#frm').trigger('submit');
        $('#action_button').attr('value', 'search');
    });
    
});