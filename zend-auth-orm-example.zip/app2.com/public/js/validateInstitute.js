$(document).ready(function () {
    $(document).on('keydown', '#ppincode,#rpincode', function (event) {
        // Prevent shift key since its not needed
        if (event.shiftKey == true) {
            event.preventDefault();
        }
        // Allow Only: keyboard 0-9, numpad 0-9, backspace, tab, left arrow, right arrow, delete
        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46) {
            // Allow normal operation
        } else {
            // Prevent the rest
            event.preventDefault();
        }
    });

    
    $('.nav').on('click','#contacts-view,#address-view', function () {
        
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        if(status!='contacts')
        {
            var ajax_dta = ajaxValidate(status, page_name, frm_data);
        }
        var IsError=$('#IsError').val();
        if(IsError==1)
        {
             return false;
        }
        
        ($(this).attr('id') == 'contacts-view') ? $('#frm_status').val('address') : '';
        ($(this).attr('id') == 'address-view') ? $('#frm_status').val('home') : '';
        InsituteValidate();
    });
    
    $('#home-view').click(function () {
        $('#frm_status').val('home');
        $('#previous').addClass('hidden');
        $('#next').removeClass('hidden');
        $('#save').addClass('hidden');
    });
    $('#previous-view').click(function(){
        InstitutePrevious();
    });
    $('#next-view').click(function(){
        InsituteValidate();
    });

});
function InsituteValidate()
{
    var status = $('#frm_status').val();
    if (status == 'home')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#address').addClass('active');
        $('#contacts').removeClass('active');
        $('.previous').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
    if (status == 'address')
    {
        $('#frm_status').val('contacts');
        $('#home').removeClass('active');
        $('#address').removeClass('active');
        $('#contacts').addClass('active');
        $('.previous').removeClass('hidden');
        $('.next').addClass('hidden');
        $('#save').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#contacts-view').addClass('active');
        $('#contacts-view-tab').addClass('active');
        return false;
    }
}
function InstitutePrevious()
{
    var status = $('#frm_status').val();
    if (status == 'address')
    {
        $('#frm_status').val('home');
        $('#home').addClass('active');
        $('#address').removeClass('active');
        $('#contacts').removeClass('active');
        $('.previous').addClass('hidden');
        $('#save').addClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#home-view').addClass('active');
        $('#home-view-tab').addClass('active');
        return false;
    }
    if (status == 'contacts')
    {
        $('#frm_status').val('address');
        $('#home').removeClass('active');
        $('#address').addClass('active');
        $('#contacts').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').removeClass('hidden');
        $('#save').addClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#address-view').addClass('active');
        $('#address-view-tab').addClass('active');
        return false;
    }
}



