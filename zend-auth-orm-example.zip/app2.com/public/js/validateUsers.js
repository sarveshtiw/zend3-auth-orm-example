$(document).ready(function () {
    $(document).on('keydown', '#UserDuration', function (event) {
        // Prevent shift key since its not needed
        if (event.shiftKey == true) {
            event.preventDefault();
        }
        // Allow Only: keyboard 0-9, numpad 0-9, backspace, tab, left arrow, right arrow, delete
        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46) {
            // Allow normal operation
        } else {
            // Prevent the rest
            event.preventDefault();
        }
    });
    
    $('#frm').on('blur', '#UserPassword', function (e) {
        $('#error-UserPassword').html('');
        if(this.value.length<6)
        {
            $('#error-UserPassword').html('Please enter at least 6 digit paswword.');
            return false;
        }
    });
    
    
    $('.nav').on('click', '#role-view', function () {
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        if(status!='contacts')
        {
            var ajax_dta = ajaxValidate(status, page_name, frm_data,'next');
        }
        var IsError=$('#IsError').val();
        if(IsError==1)
        {
             return false;
        }
        ($(this).attr('id') == 'role-view') ? $('#frm_status').val('home') : '';
        UsersNext();
    });
    $('#home-view').click(function () {
        $('#frm_status').val('home');
        $('#previous').addClass('hidden');
        $('#next').removeClass('hidden');
        $('#save').addClass('hidden');
    });
    
    // View Details
    
    $('#previous-view').click(function(){
        UsersPrevious();
    });
    $('#next-view').click(function(){
        UsersNext();
    });

});
function UsersNext()
{
    var status = $('#frm_status').val();
    if (status == 'home')
    {
        $('#frm_status').val('role');
        $('#home').removeClass('active');
        $('#role').addClass('active');
        $('.next').addClass('hidden');
        $('.previous').removeClass('hidden');
        $('#save').removeClass('hidden');
        $('.nav li.active').removeClass('active');
        $('#role-view').addClass('active');
        $('#role-view-tab').addClass('active');
        
        return false;
    }
   
}
function UsersPrevious()
{
    var status = $('#frm_status').val();
    var Id=$('#UserId').val();
    if (status == 'role')
    {
        $('#frm_status').val('home');
        $('#home').addClass('active');
        $('#role').removeClass('active');
        $('.next').removeClass('hidden');
        $('.previous').addClass('hidden');
        if(Id=='')
        {
           $('#save').addClass('hidden'); 
        }
        $('.nav li.active').removeClass('active');
        $('#home-view').addClass('active');
        $('#home-view-tab').addClass('active');
        return false;
    }
}


