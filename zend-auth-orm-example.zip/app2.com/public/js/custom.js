function webTabFunction(tabName, _type) {
 
 var vmobile = $("#verifymobile").val();
 $('#payment')[0].reset();
 $('#errorMsgdebitcard').html('');
 $('#errorMsgcreditcard').html('');
 $('#errorMsg').html('');
 
 $("#errorMsgcreditcard").addClass("hidden");
 $("#errorMsgdebitcard").addClass("hidden");
 if(vmobile==0){
            $.ajax({
                    url: sBase+"/payment/check-verification",
                    type: "POST",
                    data: ({mobile_number:$("#mobile_number").val()}),
                    success: function (response)
                    {
                        
                        if (response == 0) {
                            if(tabName!='verify_otp_info'){
                            $("#result").html("Please verify your mobile number.");
                            $("#result").addClass("red");
                            }
                            $('.cddiv').removeClass('tab');
                            $('.cddiv').addClass('tab_disable');
                            $('.tab:first').addClass('active');
                            return false;
                        }
                        else
                        {
                           $(".hidden").hide();
                           $('.cddiv').removeClass('tab_disable');
                            
                           $('.cddiv').addClass('tab');
                           
                            $('.tab').removeClass('active');
                            document.getElementById(tabName).style.display = 'block';
                            document.getElementById(tabName).class += 'active';
                            $("#type").val(_type);
                            
                            return false;
                        }
                    }
                    });
                    
                }
                else{
                            $(".hidden").hide();
                            $('.tab').removeClass('active');
                            document.getElementById(tabName).style.display = 'block';
                            document.getElementById(tabName).class += 'active';
                            $("#resultm").html("");
                            $("#type").val(_type);
                            if(_type==4 || tabName=='cod_info'){
                                $('.tab:first').addClass('active');
                            }else
                            if(tabName=='credit_card_info'){
                                $('.tab:first').addClass('active');
                            }
                            return false;
                }
 
                    
}

function mobileTabFunction(ptr) {
    var vmobile = $("#verifymobile").val();
    arrVal = ptr.value.split('|');
    
    $("#errorMsgcreditcard").addClass("hidden");
    $("#errorMsgdebitcard").addClass("hidden");
    $(':input','#payment')
    .not(':button, :submit, :reset, :hidden,#payOption')
    .val('')
    .removeAttr('checked')
    .removeAttr('selected');
    $('#errorMsgdebitcard').html('');
    $('#errorMsgcreditcard').html('');
    $('#errorMsg').html('');
    if(vmobile==0){
            $.ajax({
                    url: sBase+"/payment/check-verification",
                    type: "POST",
                    data: ({mobile_number:$("#mobile_number").val()}),
                    success: function (response)
                    {
                        
                        if (response == 0) {
                            if(arrVal['0']!='verify_otp_info'){
                            $("#resultm").html("Please verify your mobile number.");
                            $("#resultm").addClass("red");
                           
                            }
                            else
                            {
                                $("#resultm").html("");
                            }
                            $("#payOption").val($("#payOption option:first").val());
                            
                            return false;
                        }
                        
                    }
                    });
                }
                else{
                	
                    $(".hidden").hide();
                    $('.tab').removeClass('active');
                    
                    document.getElementById(arrVal[0]).style.display = 'block'
                    document.getElementById(arrVal[0]).class += 'active'

                    $("#type").val(arrVal[1]);
                }
    
}

$( document ).ready(function() {
//alert('hi');
 $(".dtab").on('click',function(event) {
            event.preventDefault();
            
        });
$(".hidden").hide();
$(".hidden:first").show();
$(".tab:first").addClass('active');
 
 $(".tab").click(function(){
	 $('.tab').removeClass('active');
    $(this).addClass('active');
});

 $('.payu_wallet').click(function(){ /* click handler for images */
     
		
     $(".payu_wallet").attr('src',sBase+'/public/images/payu_active.png'); /* change source */
		$(".airtelmoney_wallet").attr('src',sBase+'/public/images/airtelmoney.png');
		$(".askme_wallet").attr('src',sBase+'/public/images/askme.png');


});


$('.airtelmoney_wallet').click(function(){ /* click handler for images */

     $(".payu_wallet").attr('src',sBase+'/public/images/payu.png'); /* change source */
		$(".airtelmoney_wallet").attr('src',sBase+'/public/images/airtelmoney_active.png');
		$(".askme_wallet").attr('src',sBase+'/public/images/askme.png');


});


$('.askme_wallet').click(function(){ /* click handler for images */

     $(".payu_wallet").attr('src',sBase+'/public/images/payu.png'); /* change source */
		$(".airtelmoney_wallet").attr('src',sBase+'/public/images/airtelmoney.png');
		$(".askme_wallet").attr('src',sBase+'/public/images/askme_active.png');


});


$('.card_visa').click(function(){ /* click handler for images */

     $(".card_visa").attr('src',sBase+'/public/images/visa_active.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard.png');
		$(".card_american").attr('src',sBase+'/public/images/americanexpress.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay.png');
                $(".card_mestro").attr('src',sBase+'/public/images/maestro.png');

});

$('.card_master').click(function(){ /* click handler for images */

                $(".card_visa").attr('src',sBase+'/public/images/visa.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard_active.png');
		$(".card_american").attr('src',sBase+'/public/images/americanexpress.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay.png');
                $(".card_mestro").attr('src',sBase+'/public/images/maestro.png');


});

$('.card_mestro').click(function(){ /* click handler for images */

                $(".card_visa").attr('src',sBase+'/public/images/visa.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard.png');
		$(".card_mestro").attr('src',sBase+'/public/images/maestro_active.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay.png');


});

$('.card_american').click(function(){ /* click handler for images */

                $(".card_visa").attr('src',sBase+'/public/images/visa.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard.png');
		$(".card_american").attr('src',sBase+'/public/images/americanexpress_active.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay.png');
                $(".card_mestro").attr('src',sBase+'/public/images/maestro.png');


});


$('.card_rupay').click(function(){ /* click handler for images */      
     $(".card_visa").attr('src',sBase+'/public/images/visa.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard.png');
		$(".card_american").attr('src',sBase+'/public/images/americanexpress.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay_active.png');      
                $(".card_mestro").attr('src',sBase+'/public/images/maestro.png');
});


$('.kotak').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak_active.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');      
});

$('.citi').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi_active.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');      
});

$('.sbi').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi_active.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');      
});

$('.icici').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici_active.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');      
});

$('.axis').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis_active.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');      
});

$('.canara').click(function(){ /* click handler for images */      
     $(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara_active.png');      
});

$('.nbSelect').on('change', function() {

		$(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');   

});

$('.tab').click(function(){ /* click handler for images */      
    
	   	$(".payu_wallet").attr('src',sBase+'/public/images/payu.png'); /* change source */
		$(".airtelmoney_wallet").attr('src',sBase+'/public/images/airtelmoney.png');
		$(".askme_wallet").attr('src',sBase+'/public/images/askme.png');
		
		$(".kotak").attr('src',sBase+'/public/images/kotak.png'); /* change source */
		$(".citi").attr('src',sBase+'/public/images/citi.png');
		$(".sbi").attr('src',sBase+'/public/images/sbi.png');
		$(".icici").attr('src',sBase+'/public/images/icici.png');   
		$(".axis").attr('src',sBase+'/public/images/axis.png');
		$(".canara").attr('src',sBase+'/public/images/canara.png');   
		
		$(".card_visa").attr('src',sBase+'/public/images/visa.png'); /* change source */
		$(".card_master").attr('src',sBase+'/public/images/mastercard.png');
		$(".card_american").attr('src',sBase+'/public/images/americanexpress.png');
		$(".card_rupay").attr('src',sBase+'/public/images/rupay.png');      
		
});



if ($(window).width() <= 800){	
	
	$('.shipping').click(function(){ /* click handler for images */      
    
	   	$(".shipping-info ").toggle();
		
	});

	$('.cart-detail').click(function(){ /* click handler for images */      
    
	   	$(".table-style").toggle();
		
	});

}	



});

function selectBank(_bank){
	//alert(_bank);
	
	$("#bank_code").val(_bank);
	
}

function selectCartType(cardType){
	$("#cardType").val(cardType);
}