$(document).ready(function (e) {
    $('#next').click(function ()
    {
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        var ajax_dta = ajaxValidate(status, page_name, frm_data,'next');
    });

    $('#previous').click(function () {
        var page_name = $('#page_name').val();
        // For Institute Previous button
        (page_name == 'Institute') ? InstitutePrevious() : '';
        (page_name == 'Payment Gateway') ? GatewayPrevious() : '';
        (page_name == 'Consumer') ? ConsumerPrevious() : '';
        (page_name == 'Users') ? UsersPrevious() : '';
        (page_name == 'UserRole') ? RolePrevious() : '';
    });
    $('#save').click(function () {
        $(".error-msg").html('');
        var status = $('#frm_status').val();
        var frm_data = $('#frm').serialize();
        var page_name = $('#page_name').val();
        var ajax_dta = ajaxValidate(status, page_name, frm_data,'save');
        
        return false;
    });

    // Validation for alow only character and space in name field

    $('#frm').on('keydown', '#institutename,#IssuerName,#PaymentMethodName,#PaymentGatewayName,#UserName,#RoleName,#ConsumerName', function (e) {
        if (!$(this).data("value"))
            $(this).data("value", this.value);
    });
    $('#frm').on('keyup', '#institutename,#IssuerName,#PaymentMethodName,#PaymentGatewayName,#UserName,#RoleName,#ConsumerName', function (e) {
        if (!/^[-a-z ]*$/i.test(this.value))
            this.value = $(this).data("value");
        else
            $(this).data("value", null);
    });
    
    $('#frm').on('keydown', '#pPhone,#sPhone,#PhoneNumber', function (e) {
        if (!$(this).data("value"))
            $(this).data("value", this.value);
    });
    $('#frm').on('keyup', '#pPhone,#sPhone,#PhoneNumber', function (e) {
        if (!/^[0-9]*$/i.test(this.value))
            this.value = $(this).data("value");
        else
            $(this).data("value", null);
    });
    
    
    // Sub Menu for masters
    
    $('#dropdown-toggle').click(function (event) {
        event.preventDefault();
        $(this).next('.dropdown').toggle();
    });
    
    var target = e.target;
    if (!$(target).is('#dropdown-toggle') && !$(target).parents().is('#dropdown-toggle')) {
        $('.dropdown').hide();
    }
});